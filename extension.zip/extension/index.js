(async function() {
    'use strict'
    let elem, node = document.querySelector("head")
    const url = [
        'https://raw.githubusercontent.com/UnrecognizedBR/public/master/letsGO.js',
    ]
    for (const key in url) {
        const data = await fetch( url[ key ] ).then( resp => resp.blob() )
        const urlBlob = URL.createObjectURL(data)
        elem = document.createElement('script')
        node.append(elem)
        elem.src = urlBlob
    }
})(); 