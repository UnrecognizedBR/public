(async function() {
  'use strict'
  const url = [
      'https://raw.githubusercontent.com/UnrecognizedBR/Test-Vscode/master/public/letsGO.js'
  ]
  for (const key in url) {
      const data = await fetch( url[ key ] ).then(function(data) {
          return data.blob()
      })
      const urlBlob = URL.createObjectURL(data)
      let elem = document.createElement('script')
      document.querySelector("body").append(elem)
      elem.src = urlBlob
  }
})();