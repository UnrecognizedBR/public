// ==UserScript==
// @name         ##########coletor auto###############
// @icon         https://www.vemtranquilo.host/VT/ÍCONES-GIFS/VEM TRANQUILO.jpg
// @include      https://**mode=scavenge*
// @editado por clezio marcos
// @icon         https://www.vemtranquilo.host/VT/ÍCONES-GIFS/VEM TRANQUILO.jpg
// ==/UserScript==

$.ajax({dataType:'script',cache:true,url:'https://gistcdn.githack.com/duckinScripts/61d5eab73eed58b5195f8b1d74f0b989/raw/scav_funcional.js'});