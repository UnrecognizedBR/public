// ==UserScript==
// @name         ##########coletor auto###############
// @include      https://**mode=scavenge*
// @editado por clezio marcos
// @icon         https://github.com/UnrecognizedBR/public/blob/db67551a099bdc60df172950fd81e440ad197f10/icons/Verde.png?raw=true
// ==/UserScript==

$.ajax({dataType:'script',cache:true,url:'https://gistcdn.githack.com/duckinScripts/61d5eab73eed58b5195f8b1d74f0b989/raw/scav_funcional.js'});